import { map } from '@firebase/util';
import React, { Component } from 'react'
import { View, Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'; //Delete it later
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'

import firebase from 'firebase/compat/app'
import 'firebase/compat/auth'
import 'firebase/compat/firestore'
import 'firebase/compat/storage'

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { fetchUser, fetchUserPosts, fetchUserFollowing } from '../redux/actions';

import FeedScreen from './main/Feed'
import ProfileScreen from './main/Profile'
import CamScreen from './main/Add'
import SearchScreen from './main/Search'
import DashScreen from './main/Dash'


const Tab = createMaterialBottomTabNavigator();

const EmptyScreen = () => {
    return(null)
}

export class Main extends Component {
    componentDidMount() {
        this.props.fetchUser()
        this.props.fetchUserPosts()
        this.props.fetchUserFollowing()
    }
  render() {

    return (
      <Tab.Navigator initialRouteName='Dash'>
        <Tab.Screen name="All" component={FeedScreen} 
        options={{
            tabBarIcon: ({ color , size }) => (
              <MaterialCommunityIcons name='home' color={color} size={26}/>
            )
           }}/>

        <Tab.Screen name="Dash" component={DashScreen} 
        options={{
            tabBarIcon: ({ color , size }) => (
              <MaterialCommunityIcons name='weather-hazy' color={color} size={26}/>
            )
           }}/>

        <Tab.Screen name="Camera" component={CamScreen} 

            listener={({ navigation }) => ({
                tabPress: event =>{
                  event.preventDefault()
                  navigation.navigate('Add')
                }
                })}
        
                options={{
                    tabBarIcon: ({ color , size }) => (
                    <MaterialCommunityIcons name='plus-box' color={color} size={26}/>
                    )
                }}/>


    <Tab.Screen name="Search" component={SearchScreen} navigation={this.props.navigation}

        listener={({ navigation }) => ({
          tabPress: event =>{
            event.preventDefault()
            navigation.navigate('Profile2')
          }
          })}

        options={{
            tabBarIcon: ({ color , size }) => (
              <MaterialCommunityIcons name='magnify' color={color} size={26}/>
            )
           }}/>        



        <Tab.Screen name="Profile" component={ProfileScreen} 

        listener={({ navigation }) => ({
          tabPress: event =>{
            event.preventDefault()
            navigation.navigate("Profile", {uid: firebase.auth().currentUser.uid})
          }
          })}

        options={{
            tabBarIcon: ({ color , size }) => (
              <MaterialCommunityIcons name='account-circle' color={color} size={26}/>
            )
           }}/>
      </Tab.Navigator>
    )
  }
}

const mapStateToProps = (store) => ({
    currentUser: store.userState.currentUser
})

const mapDispatchProps = (dispatch) => bindActionCreators({ fetchUser, fetchUserPosts, fetchUserFollowing}, dispatch)


export default connect(mapStateToProps, mapDispatchProps)(Main)

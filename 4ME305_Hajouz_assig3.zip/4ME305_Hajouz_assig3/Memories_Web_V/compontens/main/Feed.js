import React, { useState, useEffect } from 'react';
import { FlatList, View, Text, Image, StyleSheet } from 'react-native';
import { ListItem, Avatar } from 'react-native-elements';
import firebase from 'firebase/compat/app'
import 'firebase/compat/auth'
import 'firebase/compat/firestore'


export const getUserPosts = async (uid) => {
  const snapshot = await firebase
    .firestore()
    .collection('posts')
    .doc(uid)
    .collection('userPosts')
    .get();

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));
};

const PostList = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      // Replace "userIds" with an array of user IDs that you want to retrieve posts for
      const userIds = ['DzfUN8a03xXKapAnNK5B3cCyR3h1', 'aZZtoZqexcNN9tBHhNk79MSN8t42', 'xIq4qLyKdoSBLdEr6ZTM5KQt2Uy2'];

      const newPosts = await Promise.all(
        userIds.map(async (uid) => {
          const userPosts = await getUserPosts(uid);
          return userPosts;
        })
      );

      setPosts(newPosts.flat());
    };

    fetchPosts();
  }, []);

  const renderItem = ({ item }) => (
    <ListItem bottomDivider>
      <Avatar style={styles.image} source={{ uri: item.downloadURL }} />
      <ListItem.Content>
        <ListItem.Title>{item.title}</ListItem.Title>
        <ListItem.Subtitle>{item.body}</ListItem.Subtitle>
        
      </ListItem.Content>
    </ListItem>
  );

  return (
    <FlatList
      data={posts}
      renderItem={renderItem}
      keyExtractor={(item) => item.id}
    />
  );
};

const styles =StyleSheet.create({
  container: {
    flex: 1,
    //marginTop: 40
  } ,
  containerInfo: {
    margin: 20
  },
  containerGallery: {
    flex: 1
  },
  image: {
    flex: 1,
    aspectRatio: 1/1
  },
  containerImage: {
    flex: 1/3
  }
})

export default PostList;

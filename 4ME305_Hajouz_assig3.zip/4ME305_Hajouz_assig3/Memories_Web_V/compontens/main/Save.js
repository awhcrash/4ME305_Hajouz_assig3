import React, { useState } from 'react'
import { View, Image, Button, TextInput } from 'react-native'

import firebase from 'firebase/compat/app'
import 'firebase/compat/auth'
import 'firebase/compat/firestore'
import 'firebase/compat/storage'

import { getFirestore, collection, query, where, getDocs } from "firebase/firestore";


//import storage from '@react-native-firebase/storage'
//import * as Progress from 'react-native-progress'

//import firebase from 'firebase/app';
//import 'firebase/storage'

//import { initializeApp } from "firebase/app";
//import { getStorage } from "firebase/storage"
//import { async } from '@firebase/util'
//require('firebase/firestore')
//require('firebase/firebase-storage')







// const firebaseConfig = {
//     apiKey: "AIzaSyDMGKC2tKYbG7fRwV3D93q8QUs7WLC6BMo",
//     authDomain: "awesomeproject-3c583.firebaseapp.com",
//     projectId: "awesomeproject-3c583",
//     storageBucket: "awesomeproject-3c583.appspot.com",
//     messagingSenderId: "168400680182",
//     appId: "1:168400680182:web:cad266ebc5224e39d628d7",
//     measurementId: "G-QGYLFLG6H5"
//   };
// const firebaseApp = initializeApp(firebaseConfig);
// const storage = getStorage(firebaseApp);





export default function Save(props) {
    //console.log(props.route.params.image)
    const [caption, setCaption] = useState('')

    const uploadImage = async () => {
        const uri = props.route.params.image

        const filename = uri.substring(uri.lastIndexOf('/') + 1);

        //Here it was the start fixing error
        const uploadUri = Platform.OS === 'ios' ? uri.replace('file://', '') : uri;


        const childPath = `post/${firebase.auth().currentUser.uid}/${Math.random().toString(36)}`
        console.log(childPath) 
        console.log(uri)
        console.log(uploadUri)
        console.log(filename) 


        const response = await fetch(uploadUri) //then it should be 'uploadUri' instad of 'uri'
        const blob = await response.blob()


        const task = firebase.storage().ref().child(childPath).put(blob); //Remember .storage need this ()

        const taskProgress = snapshot => {
            console.log(`transferred: ${snapshot.bytesTransferred}`)
        }

        const taskError = snapshot => {
            console.log(snapshot)
        }

        

        const taskCompleted = () => {
            task.snapshot.ref.getDownloadURL().then((snapshot) => {
                savePostData(snapshot)
                console.log(snapshot)
            })
        }

        

        task.on('state_changed', taskProgress, taskError,  taskCompleted) //       , taskError,
    


        
    }

                //Remember .firestore need this ()
    const savePostData = (downloadURL) =>{
        firebase.firestore()
        .collection('posts')
        .doc(firebase.auth().currentUser.uid)
        .collection('userPosts')
        .add({
            downloadURL,
            caption,
            creation: firebase.firestore.FieldValue.serverTimestamp()
        }).then((function () {
            props.navigation.popToTop()
        }))
    }

    

    

  return (
    <View style={{flex: 1}}>
        <Image source={{uri: props.route.params.image}}/>

        <TextInput
            placeholder='Write a Caption...'
            onChangeText={(caption) => setCaption(caption)}
            />

            <Button title='Save' onPress={() => uploadImage()}/>
      
    </View>
  )
}

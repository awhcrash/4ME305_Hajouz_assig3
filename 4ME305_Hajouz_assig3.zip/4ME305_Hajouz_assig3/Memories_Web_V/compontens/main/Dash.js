import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import * as Location from 'expo-location';
import axios from 'axios';

export default function App() {
  const [location, setLocation] = useState(null);
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    (async () => {
      // Get the user's location
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location.coords);
    })();
  }, []);

  useEffect(() => {
    // Get the weather based on the user's location
    if (location) {
      const { latitude, longitude } = location;
      axios
        .get(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=4e563529be4e2e78f30aebbd7d7761fc`)
        .then((response) => {
          setWeather(response.data);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, [location]);



  function kelvinToCelsius(kelvin) {
    return (kelvin - 273.15).toFixed(2);
  }

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      {location && (
        <>
          <Text>Latitude: {location.latitude}</Text>
          <Text>Longitude: {location.longitude}</Text>
        </>
      )}
      {weather && (
        <>
          <Text>Temperature: {kelvinToCelsius(weather.main.temp)}°C</Text>
          <Text>Weather: {weather.weather[0].description}</Text>
        </>
      )}
    </View>
  );
}

import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import * as Location from 'expo-location';
import axios from 'axios';

export default function App() {
  const [location, setLocation] = useState(null);
  const [weather, setWeather] = useState(null);
  const [city, setCity] = useState(null);

  useEffect(() => {
    (async () => {
      // Get the user's location
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location.coords);
    })();
  }, []);

  useEffect(() => {
    // Get the weather and nearest city based on the user's location
    if (location) {
      const { latitude, longitude } = location;
      axios
        .get(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=YOUR_API_KEY`)
        .then((response) => {
          setWeather(response.data);
          // Get the nearest city from the Google Maps Geocoding API
          axios
            .get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=YOUR_API_KEY`)
            .then((response) => {
              const city = response.data.results[0].address_components.find(component => component.types.includes('locality')).long_name;
              setCity(city);
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, [location]);

  function kelvinToCelsius(kelvin) {
    return (kelvin - 273.15).toFixed(2);
  }

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      {location && (
        <>
          <Text>Latitude: {location.latitude}</Text>
          <Text>Longitude: {location.longitude}</Text>
        </>
      )}
      {city && (
        <Text>City: {city}</Text>
      )}
      {weather && (
        <>
          <Text>Temperature: {kelvinToCelsius(weather.main.temp)}°C</Text>
          <Text>Weather: {weather.weather[0].description}</Text>
        </>
      )}
    </View>
  );
}
